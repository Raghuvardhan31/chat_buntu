import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:chataway_plus/core/themes/colors/app_colors.dart';
import 'package:chataway_plus/core/themes/app_text_styles.dart';
import 'package:chataway_plus/core/responsive_layout/responsive_layout_builder.dart';
import 'package:chataway_plus/features/chat/presentation/pages/chat_list/widgets/group_chat_list_tile_widget.dart';
import 'package:chataway_plus/features/group_chat/presentation/providers/group_providers.dart';
import 'package:chataway_plus/features/chat/presentation/pages/chat_list/widgets/chat_list_empty_states.dart';
import 'package:chataway_plus/features/chat/utils/chat_helper.dart';

class GroupListPage extends ConsumerStatefulWidget {
  const GroupListPage({super.key});

  @override
  ConsumerState<GroupListPage> createState() => _GroupListPageState();
}

class _GroupListPageState extends ConsumerState<GroupListPage> {
  String? _currentUserId;

  @override
  void initState() {
    super.initState();
    _loadCurrentUserId();
  }

  Future<void> _loadCurrentUserId() async {
    final id = await ChatHelper.getCurrentUserId();
    if (mounted) {
      setState(() {
        _currentUserId = id;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final groupsAsync = ref.watch(myGroupsProvider);

    return ResponsiveLayoutBuilder(
      builder: (context, constraints, breakpoint) {
        final responsive = ResponsiveSize(
          context: context,
          constraints: constraints,
          breakpoint: breakpoint,
        );

        return Scaffold(
          body: groupsAsync.when(
            data: (groups) {
              if (groups.isEmpty) {
                return Center(
                  child: ChatListEmptyState(
                    responsive: responsive,
                  ),
                );
              }

              return ListView.builder(
                padding: EdgeInsets.symmetric(vertical: responsive.spacing(8)),
                itemCount: groups.length,
                itemBuilder: (context, index) {
                  final group = groups[index];
                  return GroupChatListTileWidget(
                    group: group,
                    currentUserId: _currentUserId,
                    responsive: responsive,
                    onNavigateBack: () async {
                      ref.invalidate(myGroupsProvider);
                    },
                  );
                },
              );
            },
            loading: () => const Center(
              child: CircularProgressIndicator(color: AppColors.primary),
            ),
            error: (err, stack) => Center(
              child: Text(
                'Error loading groups: $err',
                style: AppTextSizes.regular(context).copyWith(color: Colors.red),
              ),
            ),
          ),
        );
      },
    );
  }
}

import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:chataway_plus/core/constants/api_url/api_urls.dart';
import 'package:chataway_plus/core/storage/token_storage.dart';
import 'package:chataway_plus/features/chat/data/socket/core/socket_connection_manager.dart';
import 'package:chataway_plus/features/group_chat/models/group_models.dart';

/// GroupChatRepository
///
/// Handles:
/// - REST calls to /api/groups/*
/// - Socket.IO events: join-group, group-message, group-typing, etc.
class GroupChatRepository {
  // ─── Singleton ────────────────────────────────────────────────────────────
  static final GroupChatRepository _instance = GroupChatRepository._internal();
  factory GroupChatRepository() => _instance;
  static GroupChatRepository get instance => _instance;
  GroupChatRepository._internal();

  final TokenSecureStorage _tokenStorage = TokenSecureStorage();
  final SocketConnectionManager _socketManager = SocketConnectionManager();

  // ─── Streams ──────────────────────────────────────────────────────────────
  final StreamController<GroupMessageModel> _newMessageController =
      StreamController<GroupMessageModel>.broadcast();
  final StreamController<GroupMessageModel> _messageSentController =
      StreamController<GroupMessageModel>.broadcast();
  final StreamController<Map<String, dynamic>> _typingController =
      StreamController<Map<String, dynamic>>.broadcast();
  final StreamController<Map<String, dynamic>> _messageDeletedController =
      StreamController<Map<String, dynamic>>.broadcast();

  Stream<GroupMessageModel> get onNewGroupMessage => _newMessageController.stream;
  Stream<GroupMessageModel> get onGroupMessageSent => _messageSentController.stream;
  Stream<Map<String, dynamic>> get onGroupTyping => _typingController.stream;
  Stream<Map<String, dynamic>> get onGroupMessageDeleted => _messageDeletedController.stream;
  final StreamController<Map<String, dynamic>> _statusUpdateController =
      StreamController<Map<String, dynamic>>.broadcast();
  Stream<Map<String, dynamic>> get onGroupMessageStatusUpdated => _statusUpdateController.stream;
  final StreamController<Map<String, dynamic>> _messagesSyncedController =
      StreamController<Map<String, dynamic>>.broadcast();
  Stream<Map<String, dynamic>> get onGroupMessagesSynced => _messagesSyncedController.stream;
  final StreamController<void> _reconnectController = StreamController<void>.broadcast();
  Stream<void> get onReconnect => _reconnectController.stream;

  bool _listenersRegistered = false;

  // ─── Socket Listener Setup ────────────────────────────────────────────────
  void registerSocketListeners() {
    if (_listenersRegistered) return;
    final socket = _socketManager.socket;
    if (socket == null) return;

    socket.on('new-group-message', (data) {
      try {
        final map = data is Map ? Map<String, dynamic>.from(data) : <String, dynamic>{};
        final msg = GroupMessageModel.fromJson(map);
        _newMessageController.add(msg);
      } catch (e) {
        debugPrint('❌ [GroupChat] new-group-message parse error: $e');
      }
    });

    socket.on('group-message-sent', (data) {
      try {
        final map = data is Map ? Map<String, dynamic>.from(data) : <String, dynamic>{};
        final msg = GroupMessageModel.fromJson(map);
        _messageSentController.add(msg);
      } catch (e) {
        debugPrint('❌ [GroupChat] group-message-sent parse error: $e');
      }
    });

    socket.on('group-user-typing', (data) {
      try {
        final map = data is Map ? Map<String, dynamic>.from(data) : <String, dynamic>{};
        _typingController.add(map);
      } catch (e) {
        debugPrint('❌ [GroupChat] group-user-typing parse error: $e');
      }
    });

    socket.on('group-message-deleted', (data) {
      try {
        final map = data is Map ? Map<String, dynamic>.from(data) : <String, dynamic>{};
        _messageDeletedController.add(map);
      } catch (e) {
        debugPrint('❌ [GroupChat] group-message-deleted parse error: $e');
      }
    });

    socket.on('group-message-status-updated', (data) {
      try {
        final map = data is Map ? Map<String, dynamic>.from(data) : <String, dynamic>{};
        _statusUpdateController.add(map);
      } catch (e) {
        debugPrint('❌ [GroupChat] group-message-status-updated parse error: $e');
      }
    });

    socket.on('group-messages-synced', (data) {
      try {
        final map = data is Map ? Map<String, dynamic>.from(data) : <String, dynamic>{};
        _messagesSyncedController.add(map);
      } catch (e) {
        debugPrint('❌ [GroupChat] group-messages-synced parse error: $e');
      }
    });

    socket.on('connect', (_) async {
      debugPrint('⚡ [GroupChat] Socket reconnected, rejoining rooms...');
      _reconnectController.add(null);
      
      try {
        final groups = await getMyGroups();
        final ids = groups.map((g) => g.id).toList();
        if (ids.isNotEmpty) {
          socket.emit('join-groups', ids);
          debugPrint('🏠 [GroupChat] Sent join-groups for ${ids.length} groups');
        }
      } catch (e) {
        debugPrint('❌ [GroupChat] Failed to auto-rejoin groups: $e');
      }
    });

    _listenersRegistered = true;
    debugPrint('✅ [GroupChat] Socket listeners registered');
  }

  void unregisterSocketListeners() {
    final socket = _socketManager.socket;
    if (socket == null) return;
    socket.off('new-group-message');
    socket.off('group-message-sent');
    socket.off('group-user-typing');
    socket.off('group-message-deleted');
    _listenersRegistered = false;
  }

  // ─── Join / Leave Group Room ──────────────────────────────────────────────
  void joinGroupRoom(String groupId) {
    final socket = _socketManager.socket;
    if (socket == null || !socket.connected) return;
    socket.emit('join-group', groupId);
    debugPrint('📡 [GroupChat] Emitted join-group: $groupId');
  }

  void joinGroups(List<String> groupIds) {
    final socket = _socketManager.socket;
    if (socket == null || !socket.connected) return;
    socket.emit('join-groups', groupIds);
    debugPrint('📡 [GroupChat] Emitted join-groups for ${groupIds.length} groups');
  }

  void leaveGroupRoom(String groupId) {
    final socket = _socketManager.socket;
    if (socket == null) return;
    socket.emit('leave-group-room', groupId);
    debugPrint('📡 [GroupChat] Emitted leave-group-room: $groupId');
  }

  // ─── Send Group Message via Socket ───────────────────────────────────────
  Future<void> sendGroupMessage({
    required String groupId,
    String? message,
    String messageType = 'text',
    String? fileUrl,
    String? mimeType,
    Map<String, dynamic>? pollPayload,
    List<Map<String, dynamic>>? contactPayload,
    int? imageWidth,
    int? imageHeight,
    double? audioDuration,
    String? videoThumbnailUrl,
    double? videoDuration,
    String? replyToMessageId,
    String? clientMessageId,
  }) async {
    final socket = _socketManager.socket;
    if (socket == null || !socket.connected) {
      debugPrint('⚠️ [GroupChat] Socket not connected, cannot send group message');
      throw Exception('Socket disconnected');
    }

    final payload = <String, dynamic>{
      'groupId': groupId,
      if (message != null) 'message': message,
      'messageType': messageType,
      if (fileUrl != null) 'fileUrl': fileUrl,
      if (mimeType != null) 'mimeType': mimeType,
      if (pollPayload != null) 'pollPayload': pollPayload,
      if (contactPayload != null) 'contactPayload': contactPayload,
      if (imageWidth != null) 'imageWidth': imageWidth,
      if (imageHeight != null) 'imageHeight': imageHeight,
      if (audioDuration != null) 'audioDuration': audioDuration,
      if (videoThumbnailUrl != null) 'videoThumbnailUrl': videoThumbnailUrl,
      if (videoDuration != null) 'videoDuration': videoDuration,
      if (replyToMessageId != null) 'replyToMessageId': replyToMessageId,
      if (clientMessageId != null) 'clientMessageId': clientMessageId,
    };

    final completer = Completer<void>();

    socket.emitWithAck('group-message', payload, ack: (response) {
      final map = response is Map ? Map<String, dynamic>.from(response) : <String, dynamic>{};
      if (map['success'] == true && map['message'] != null) {
        final msg = GroupMessageModel.fromJson(Map<String, dynamic>.from(map['message']));
        _messageSentController.add(msg);
        debugPrint('✅ [GroupChat] Message acknowledged by server: ${msg.id}');
        completer.complete();
      } else {
        final error = map['error'] ?? 'Unknown error';
        debugPrint('❌ [GroupChat] Message rejected by server: $error');
        if (clientMessageId != null) {
          _messageDeletedController.add({'messageId': clientMessageId, 'groupId': groupId, 'error': error});
        }
        completer.completeError(error);
      }
    });

    debugPrint('📤 [GroupChat] Emitted group-message to $groupId with clientMessageId: $clientMessageId');
    return completer.future;
  }

  // ─── Typing Indicator ─────────────────────────────────────────────────────
  void sendTyping(String groupId, {required bool isTyping}) {
    final socket = _socketManager.socket;
    if (socket == null || !socket.connected) return;
    socket.emit('group-typing', {'groupId': groupId, 'isTyping': isTyping});
  }

  void startTyping(String groupId) => sendTyping(groupId, isTyping: true);
  void stopTyping(String groupId) => sendTyping(groupId, isTyping: false);

  // ─── Message Status ───────────────────────────────────────────────────────
  void updateGroupMessageStatus({
    required List<String> chatIds,
    required String groupId,
    required String status,
  }) {
    final socket = _socketManager.socket;
    if (socket == null || !socket.connected) return;
    socket.emit('update-group-message-status', {
      'chatIds': chatIds,
      'groupId': groupId,
      'status': status,
    });
  }

  // ─── Sync Messages ────────────────────────────────────────────────────────
  void syncGroupMessages({required String groupId, String? lastSeenTimestamp}) {
    final socket = _socketManager.socket;
    if (socket == null || !socket.connected) return;
    socket.emit('sync-group-messages', {
      'groupId': groupId,
      'lastSeenTimestamp': lastSeenTimestamp,
    });
  }

  // ─── REST: Create Group ───────────────────────────────────────────────────
  Future<GroupModel> createGroup({
    required String name,
    required List<String> memberIds,
    String? description,
    String? icon,
    bool isRestricted = false,
  }) async {
    final token = await _tokenStorage.getToken();
    final response = await http.post(
      Uri.parse('${ApiUrls.apiBaseUrl}/groups'),
      headers: _headers(token),
      body: jsonEncode({
        'name': name,
        'memberIds': memberIds,
        if (description != null) 'description': description,
        if (icon != null) 'icon': icon,
        'isRestricted': isRestricted,
      }),
    );

    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode == 201 && body['success'] == true) {
      return GroupModel.fromJson(body['data'] as Map<String, dynamic>);
    }
    throw Exception(body['error'] ?? 'Failed to create group');
  }

  // ─── REST: Get My Groups ──────────────────────────────────────────────────
  Future<List<GroupModel>> getMyGroups() async {
    final token = await _tokenStorage.getToken();
    final response = await http.get(
      Uri.parse('${ApiUrls.apiBaseUrl}/groups/my'),
      headers: _headers(token),
    );

    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode == 200 && body['success'] == true) {
      final list = body['data'] as List<dynamic>;
      return list.map((e) => GroupModel.fromJson(e as Map<String, dynamic>)).toList();
    }
    throw Exception(body['error'] ?? 'Failed to fetch groups');
  }

  // ─── REST: Get Group Details ──────────────────────────────────────────────
  Future<GroupModel> getGroupDetails(String groupId) async {
    final token = await _tokenStorage.getToken();
    final response = await http.get(
      Uri.parse('${ApiUrls.apiBaseUrl}/groups/$groupId'),
      headers: _headers(token),
    );

    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode == 200 && body['success'] == true) {
      return GroupModel.fromJson(body['data'] as Map<String, dynamic>);
    }
    throw Exception(body['error'] ?? 'Failed to fetch group details');
  }

  // ─── REST: Get Group Messages ─────────────────────────────────────────────
  Future<List<GroupMessageModel>> getGroupMessages(
    String groupId, {
    int page = 1,
    int limit = 50,
    String? sinceMessageId,
    String? beforeMessageId,
  }) async {
    final token = await _tokenStorage.getToken();
    final queryParams = {
      'page': '$page',
      'limit': '$limit',
      if (sinceMessageId != null) 'sinceMessageId': sinceMessageId,
      if (beforeMessageId != null) 'beforeMessageId': beforeMessageId,
    };
    final uri = Uri.parse('${ApiUrls.apiBaseUrl}/groups/$groupId/messages')
        .replace(queryParameters: queryParams);

    final response = await http.get(uri, headers: _headers(token));
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode == 200 && body['success'] == true) {
      final data = body['data'] as Map<String, dynamic>;
      final list = data['messages'] as List<dynamic>;
      return list.map((e) => GroupMessageModel.fromJson(e as Map<String, dynamic>)).toList();
    }
    throw Exception(body['error'] ?? 'Failed to fetch group messages');
  }

  // ─── REST: Update Group ───────────────────────────────────────────────────
  Future<GroupModel> updateGroup(
    String groupId, {
    String? name,
    String? description,
    String? icon,
    bool? isRestricted,
  }) async {
    final token = await _tokenStorage.getToken();
    final response = await http.put(
      Uri.parse('${ApiUrls.apiBaseUrl}/groups/$groupId'),
      headers: _headers(token),
      body: jsonEncode({
        if (name != null) 'name': name,
        if (description != null) 'description': description,
        if (icon != null) 'icon': icon,
        if (isRestricted != null) 'isRestricted': isRestricted,
      }),
    );
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode == 200 && body['success'] == true) {
      return GroupModel.fromJson(body['data'] as Map<String, dynamic>);
    }
    throw Exception(body['error'] ?? 'Failed to update group');
  }

  // ─── REST: Add Members ────────────────────────────────────────────────────
  Future<GroupModel> addMembers(String groupId, List<String> memberIds) async {
    final token = await _tokenStorage.getToken();
    final response = await http.post(
      Uri.parse('${ApiUrls.apiBaseUrl}/groups/$groupId/members'),
      headers: _headers(token),
      body: jsonEncode({'memberIds': memberIds}),
    );
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode == 200 && body['success'] == true) {
      return GroupModel.fromJson(body['data'] as Map<String, dynamic>);
    }
    throw Exception(body['error'] ?? 'Failed to add members');
  }

  // ─── REST: Remove Member / Leave Group ───────────────────────────────────
  Future<void> removeMember(String groupId, String targetUserId) async {
    final token = await _tokenStorage.getToken();
    final response = await http.delete(
      Uri.parse('${ApiUrls.apiBaseUrl}/groups/$groupId/members/$targetUserId'),
      headers: _headers(token),
    );
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode != 200 || body['success'] != true) {
      throw Exception(body['error'] ?? 'Failed to remove member');
    }
  }

  // ─── REST: Update Member Role ─────────────────────────────────────────────
  Future<void> updateMemberRole(String groupId, String targetUserId, String role) async {
    final token = await _tokenStorage.getToken();
    final response = await http.patch(
      Uri.parse('${ApiUrls.apiBaseUrl}/groups/$groupId/members/$targetUserId/role'),
      headers: _headers(token),
      body: jsonEncode({'role': role}),
    );
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode != 200 || body['success'] != true) {
      throw Exception(body['error'] ?? 'Failed to update role');
    }
  }

  // ─── REST: Delete Group ───────────────────────────────────────────────────
  Future<void> deleteGroup(String groupId) async {
    final token = await _tokenStorage.getToken();
    final response = await http.delete(
      Uri.parse('${ApiUrls.apiBaseUrl}/groups/$groupId'),
      headers: _headers(token),
    );
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode != 200 || body['success'] != true) {
      throw Exception(body['error'] ?? 'Failed to delete group');
    }
  }

  // ─── Helpers ──────────────────────────────────────────────────────────────
  Map<String, String> _headers(String? token) => {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  void dispose() {
    unregisterSocketListeners();
    _newMessageController.close();
    _messageSentController.close();
    _typingController.close();
    _messageDeletedController.close();
    _statusUpdateController.close();
    _messagesSyncedController.close();
    _reconnectController.close();
  }
}
